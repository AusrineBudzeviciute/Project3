var classstudentas =
[
    [ "studentas", "classstudentas.html#a40a99ea5d527a3d443123f4785550787", null ],
    [ "~studentas", "classstudentas.html#a74b639e1a2ffe282686999b931eb4aaa", null ],
    [ "studentas", "classstudentas.html#a0729e327e18dbb69c161248d23e33c51", null ],
    [ "clearPazymiai", "classstudentas.html#a906474288b36f644de2a755800fee286", null ],
    [ "getEgz", "classstudentas.html#ac0e514683b1825bd7a8ee077365f4214", null ],
    [ "getMediana", "classstudentas.html#a839a5a23977bf51229d266d7ef5005f2", null ],
    [ "getPavarde", "classstudentas.html#ac3b1292eafe14b4b48853f465e2a1d3c", null ],
    [ "getPazymiai", "classstudentas.html#a89561616b51a7714db7e7ae281b9de75", null ],
    [ "getRez", "classstudentas.html#a2695410b3a68278cec405cdbf3679c20", null ],
    [ "getVardas", "classstudentas.html#ac14e4b28176543a0b03970fcde7b044c", null ],
    [ "operator=", "classstudentas.html#ad4b12461e53af9dcb5f32e5be6f3a5b7", null ],
    [ "setEgz", "classstudentas.html#af77e120b0309168ad31e93fe6a8257e8", null ],
    [ "setMediana", "classstudentas.html#aa6d04c8219136d039c48899cd39e49dd", null ],
    [ "setPavarde", "classstudentas.html#ae5e20428f81b445ae4a5c97bac8974e4", null ],
    [ "setPazymiai", "classstudentas.html#a7f7233191c9474ae4486d0056596a108", null ],
    [ "setRez", "classstudentas.html#aa00dfca521ffdcb675c4cd3222d7d412", null ],
    [ "setVardas", "classstudentas.html#a22e789856433ebfd4cf120da369c2584", null ],
    [ "operator<<", "classstudentas.html#af9bbd56925d9346ba19d5bf70830f103", null ],
    [ "operator>>", "classstudentas.html#aa4cfc2d1d601c2fc9fa34031b7cfcbb2", null ]
];