var classzmogus =
[
    [ "zmogus", "classzmogus.html#a3cb03824ec8269cf401cbf615e440833", null ],
    [ "~zmogus", "classzmogus.html#a67d08c33049ff379f5c8b72745416239", null ],
    [ "getPavarde", "classzmogus.html#a855f577e5b4d194c3397a9737e935ff9", null ],
    [ "getVardas", "classzmogus.html#a906a66cffcd1ae46c422116148b4c362", null ],
    [ "setPavarde", "classzmogus.html#a2ad1b3c7cd2b33bbe3dcdf43d0f56086", null ],
    [ "setVardas", "classzmogus.html#ad47f50cd9af54cde44674395476ccc85", null ],
    [ "pavarde_", "classzmogus.html#a4df33c060374e0a9853d3fda824f0deb", null ],
    [ "vardas_", "classzmogus.html#ad20a48c056323b41af24f6891e671404", null ]
];