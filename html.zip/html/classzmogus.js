var classzmogus =
[
    [ "zmogus", "classzmogus.html#a3cb03824ec8269cf401cbf615e440833", null ],
    [ "getPavarde", "classzmogus.html#a5dfb525146fe08355f3e4aae7357c5da", null ],
    [ "getVardas", "classzmogus.html#a1c16f5d3a776dd517d3b6c3a2244d49f", null ],
    [ "setPavarde", "classzmogus.html#a5b44d4f8c1fc6191fae3840bc710b32a", null ],
    [ "setVardas", "classzmogus.html#adf004ed68150f1292a27121a88640b23", null ],
    [ "pavarde_", "classzmogus.html#a4df33c060374e0a9853d3fda824f0deb", null ],
    [ "vardas_", "classzmogus.html#ad20a48c056323b41af24f6891e671404", null ]
];