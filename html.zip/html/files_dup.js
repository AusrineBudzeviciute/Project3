var files_dup =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "my_lib.cpp", "my__lib_8cpp.html", "my__lib_8cpp" ],
    [ "my_lib.h", "my__lib_8h.html", "my__lib_8h" ]
];