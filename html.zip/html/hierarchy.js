var hierarchy =
[
    [ "zmogus", "classzmogus.html", [
      [ "studentas", "classstudentas.html", null ]
    ] ]
];