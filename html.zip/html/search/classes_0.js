var searchData=
[
  ['studentas_0',['studentas',['../classstudentas.html',1,'']]]
];
