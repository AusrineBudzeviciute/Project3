var searchData=
[
  ['clearpazymiai_0',['clearPazymiai',['../classstudentas.html#a906474288b36f644de2a755800fee286',1,'studentas']]]
];
