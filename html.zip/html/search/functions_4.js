var searchData=
[
  ['operator_3d_0',['operator=',['../classstudentas.html#ad4b12461e53af9dcb5f32e5be6f3a5b7',1,'studentas']]]
];
