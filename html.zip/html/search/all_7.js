var searchData=
[
  ['setegz_0',['setEgz',['../classstudentas.html#af77e120b0309168ad31e93fe6a8257e8',1,'studentas']]],
  ['setmediana_1',['setMediana',['../classstudentas.html#aa6d04c8219136d039c48899cd39e49dd',1,'studentas']]],
  ['setpavarde_2',['setPavarde',['../classzmogus.html#a5b44d4f8c1fc6191fae3840bc710b32a',1,'zmogus']]],
  ['setpazymiai_3',['setPazymiai',['../classstudentas.html#a7f7233191c9474ae4486d0056596a108',1,'studentas']]],
  ['setrez_4',['setRez',['../classstudentas.html#aa00dfca521ffdcb675c4cd3222d7d412',1,'studentas']]],
  ['setvardas_5',['setVardas',['../classzmogus.html#adf004ed68150f1292a27121a88640b23',1,'zmogus']]],
  ['studentas_6',['studentas',['../classstudentas.html',1,'studentas'],['../classstudentas.html#a40a99ea5d527a3d443123f4785550787',1,'studentas::studentas()'],['../classstudentas.html#a0729e327e18dbb69c161248d23e33c51',1,'studentas::studentas(const studentas &amp;o)']]]
];
