var searchData=
[
  ['_7estudentas_0',['~studentas',['../classstudentas.html#a74b639e1a2ffe282686999b931eb4aaa',1,'studentas']]],
  ['_7ezmogus_1',['~zmogus',['../classzmogus.html#a67d08c33049ff379f5c8b72745416239',1,'zmogus']]]
];
