var searchData=
[
  ['setegz_0',['setEgz',['../classstudentas.html#af77e120b0309168ad31e93fe6a8257e8',1,'studentas']]],
  ['setmediana_1',['setMediana',['../classstudentas.html#aa6d04c8219136d039c48899cd39e49dd',1,'studentas']]],
  ['setpavarde_2',['setPavarde',['../classzmogus.html#a2ad1b3c7cd2b33bbe3dcdf43d0f56086',1,'zmogus::setPavarde()'],['../classstudentas.html#ae5e20428f81b445ae4a5c97bac8974e4',1,'studentas::setPavarde(string pavarde)']]],
  ['setpazymiai_3',['setPazymiai',['../classstudentas.html#a7f7233191c9474ae4486d0056596a108',1,'studentas']]],
  ['setrez_4',['setRez',['../classstudentas.html#aa00dfca521ffdcb675c4cd3222d7d412',1,'studentas']]],
  ['setvardas_5',['setVardas',['../classzmogus.html#ad47f50cd9af54cde44674395476ccc85',1,'zmogus::setVardas()'],['../classstudentas.html#a22e789856433ebfd4cf120da369c2584',1,'studentas::setVardas(string vardas)']]],
  ['studentas_6',['studentas',['../classstudentas.html#a40a99ea5d527a3d443123f4785550787',1,'studentas::studentas()'],['../classstudentas.html#a0729e327e18dbb69c161248d23e33c51',1,'studentas::studentas(const studentas &amp;o)']]]
];
