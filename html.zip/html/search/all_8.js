var searchData=
[
  ['tikrinimas_0',['tikrinimas',['../my__lib_8cpp.html#a565d5e34b135e82a1842512f6dac15fc',1,'tikrinimas(int &amp;x):&#160;my_lib.cpp'],['../my__lib_8h.html#a565d5e34b135e82a1842512f6dac15fc',1,'tikrinimas(int &amp;x):&#160;my_lib.cpp']]]
];
