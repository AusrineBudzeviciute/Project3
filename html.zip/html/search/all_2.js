var searchData=
[
  ['generate_5frandom_0',['generate_random',['../my__lib_8cpp.html#a959585b369472c18f2b9f929f160cd09',1,'generate_random():&#160;my_lib.cpp'],['../my__lib_8h.html#a959585b369472c18f2b9f929f160cd09',1,'generate_random():&#160;my_lib.cpp']]],
  ['getegz_1',['getEgz',['../classstudentas.html#ac0e514683b1825bd7a8ee077365f4214',1,'studentas']]],
  ['getmediana_2',['getMediana',['../classstudentas.html#a839a5a23977bf51229d266d7ef5005f2',1,'studentas']]],
  ['getpavarde_3',['getPavarde',['../classzmogus.html#a5dfb525146fe08355f3e4aae7357c5da',1,'zmogus']]],
  ['getpazymiai_4',['getPazymiai',['../classstudentas.html#a89561616b51a7714db7e7ae281b9de75',1,'studentas']]],
  ['getrez_5',['getRez',['../classstudentas.html#a2695410b3a68278cec405cdbf3679c20',1,'studentas']]],
  ['getvardas_6',['getVardas',['../classzmogus.html#a1c16f5d3a776dd517d3b6c3a2244d49f',1,'zmogus']]]
];
