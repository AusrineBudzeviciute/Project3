var searchData=
[
  ['generate_5frandom_0',['generate_random',['../my__lib_8cpp.html#a959585b369472c18f2b9f929f160cd09',1,'generate_random():&#160;my_lib.cpp'],['../my__lib_8h.html#a959585b369472c18f2b9f929f160cd09',1,'generate_random():&#160;my_lib.cpp']]],
  ['getegz_1',['getEgz',['../classstudentas.html#ac0e514683b1825bd7a8ee077365f4214',1,'studentas']]],
  ['getmediana_2',['getMediana',['../classstudentas.html#a839a5a23977bf51229d266d7ef5005f2',1,'studentas']]],
  ['getpavarde_3',['getPavarde',['../classzmogus.html#a855f577e5b4d194c3397a9737e935ff9',1,'zmogus::getPavarde()'],['../classstudentas.html#ac3b1292eafe14b4b48853f465e2a1d3c',1,'studentas::getPavarde() const']]],
  ['getpazymiai_4',['getPazymiai',['../classstudentas.html#a89561616b51a7714db7e7ae281b9de75',1,'studentas']]],
  ['getrez_5',['getRez',['../classstudentas.html#a2695410b3a68278cec405cdbf3679c20',1,'studentas']]],
  ['getvardas_6',['getVardas',['../classzmogus.html#a906a66cffcd1ae46c422116148b4c362',1,'zmogus::getVardas()'],['../classstudentas.html#ac14e4b28176543a0b03970fcde7b044c',1,'studentas::getVardas()']]]
];
