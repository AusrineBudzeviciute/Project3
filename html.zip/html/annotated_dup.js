var annotated_dup =
[
    [ "studentas", "classstudentas.html", "classstudentas" ],
    [ "zmogus", "classzmogus.html", "classzmogus" ]
];